% Volume (ml)
y = [0 10 20 30 40 50 60];

% ADC values
x = [(4020.75+4020.75) 4019.6+4024.1 3851.75+3646.55 3585.9+3446.1 3442.0+3133.6 3297.15+2978.9 3115.6+3000.05]/2;

% Linear fit (degree = 1)
p = polyfit(x,y,1);

% Extract slope and intercept
m = p(1);
c = p(2);

% Display results
fprintf('Slope (m) = %.4f\n', m);
fprintf('Y-intercept (c) = %.4f\n', c);

% Plot the data and fitted line
x_fit = linspace(min(x),max(x),100);
y_fit = polyval(p,x_fit);

figure;
plot(x,y,'o','LineWidth',2);
hold on;
plot(x_fit,y_fit,'-','LineWidth',2);
xlabel('Volume (ml)');
ylabel('ADC Value');
title('Linear Fit using polyfit');
legend('Data','Best Fit Line');
grid on;